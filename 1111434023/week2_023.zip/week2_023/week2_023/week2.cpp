#include<stdio.h>

int main()
{
	int var1 = 0, var2 = 0, sum = 0;
	printf("��J�Ĥ@�Ӽ�\n");
	scanf_s("%d", &var1);
	printf("��J�ĤG�Ӽ�\n");
	scanf_s("%d", &var2);
	sum = var1 + var2;
	printf("%d + %d = %d\n ", var1, var2, sum);
	sum = var1 - var2;
	printf("%d - %d = %d\n ", var1, var2, sum);
	sum = var1 * var2;
	printf("%d * %d = %d\n ", var1, var2, sum);
	sum = var1 / var2;
	printf("%d / %d = %d\n ", var1, var2, sum);
	return 0;
}