#include <stdio.h>
#define SIZE 10

void sort(int data[], int length);
int binary_search(int data[], int key, int low, int high);

int main(void)
{
    int data[SIZE];
    int key;
    int result;

    printf("�п�J10�Ӿ�ơG\n");

    for (int i = 0; i < SIZE; i++)
    {
        scanf_s("%d", &data[i]);
    }

    sort(data, SIZE);

    printf("\n�Ѥp��j�ƧǡG\n");

    for (int i = 0; i < SIZE; i++)
    {
        printf("%4d", data[i]);
    }

    printf("\n\n�п�J�n�j�M���Ʀr�G");
    scanf_s("%d", &key);

    result = binary_search(data, key, 0, SIZE - 1);

    printf("\n========== �j�M���G ==========\n");

    if (result == 1)
    {
        printf("����ơI�Ʀr %d �s�b��}�C���C\n", key);
    }
    else
    {
        printf("�䤣���ơI�Ʀr %d ���s�b��}�C���C\n", key);
    }

    return 0;
}

void sort(int data[], int length)
{
    int hold;

    for (int pass = 1; pass < length; pass++)
    {
        for (int i = 0; i < length - pass; i++)
        {
            if (data[i] > data[i + 1])
            {
                hold = data[i];
                data[i] = data[i + 1];
                data[i + 1] = hold;
            }
        }
    }
}

int binary_search(int data[], int key, int low, int high)
{
    int mid;

    while (low <= high)
    {
        mid = (low + high) / 2;

        if (data[mid] == key)
        {
            return 1;
        }
        else if (data[mid] < key)
        {
            low = mid + 1;
        }
        else
        {
            high = mid - 1;
        }
    }

    return 0;
}